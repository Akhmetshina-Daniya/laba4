﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace laba4
{
    public partial class Form1 : Form
    {
        public delegate void ThreadStartr();
        bool flag1 = true;
        void Print()
        {
            int oi = 0 ;
            while (flag1)
            {
                oi++;
                this.label1.BeginInvoke((MethodInvoker)(()=>this.label1.Text=$"{oi.ToString()}"));
                Console.WriteLine(Thread.CurrentThread.Priority);
                Thread.Sleep(100);
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            flag1 = true;
            Thread mypotok = new Thread(Print);
            mypotok.Start();
            button4.Tag = mypotok;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            flag1 = false;
        }
        int numb = 0;
        private void button4_Click(object sender, EventArgs e)
        {
            Thread thread = (Thread)button4.Tag;
            if(numb == 0)
            {
                thread.Priority = ThreadPriority.Highest;
                numb = 1;
            }
            else if(numb == 1)
            {
                thread.Priority = ThreadPriority.Lowest;
                numb = 0;
            }
                
        }
    }
}
